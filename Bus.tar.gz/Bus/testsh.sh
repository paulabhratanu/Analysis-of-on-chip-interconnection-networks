for word in $(<testsh.txt)
do
    echo "$word"
done
