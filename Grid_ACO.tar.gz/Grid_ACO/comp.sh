exec g++ -Wall *.cpp -o aco; ./aco &

