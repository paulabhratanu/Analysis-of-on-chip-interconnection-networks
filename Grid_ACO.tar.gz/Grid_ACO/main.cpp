/*
@author:	Diogo A. B. Fernandes
@contact:	diogoabfernandes@gmail.com
@license:	see LICENSE
*/

#include <iostream>
#include <cstdlib>

#include <cmath>
#include <limits>
#include <climits>
#include <stdio.h>
#include "ACO.h"

#define ITERATIONS		(int) 5

#define NUMBEROFANTS	(int) 6
#define NUMBEROFCITIES	(int) 16

// if (ALPHA == 0) { stochastic search & sub-optimal route }
#define ALPHA			(double) 0.5
// if (BETA  == 0) { sub-optimal route }
#define BETA			(double) 0.8
// Estimation of the suspected best route.
#define Q				(double) 80
// Pheromones evaporation. 
#define RO				(double) 0.2
// Maximum pheromone random number.
#define TAUMAX			(int) 2

#define INITIALCITY		(int) 0

int main(int argc, char* argv[]) {
        int gh1,gh;
	ACO *ANTS = new ACO (NUMBEROFANTS, NUMBEROFCITIES, 
			 			ALPHA, BETA, Q, RO, TAUMAX,
			 			INITIALCITY);

	ANTS -> init();

	/*ANTS -> connectCITIES (0, 1);
	ANTS -> connectCITIES (0, 2);
	ANTS -> connectCITIES (0, 3);
	ANTS -> connectCITIES (0, 7);
	ANTS -> connectCITIES (1, 3);
	ANTS -> connectCITIES (1, 5);
	ANTS -> connectCITIES (1, 7);
	ANTS -> connectCITIES (2, 4);
	ANTS -> connectCITIES (2, 5);
	ANTS -> connectCITIES (2, 6);
	ANTS -> connectCITIES (4, 3);
	ANTS -> connectCITIES (4, 5);
	ANTS -> connectCITIES (4, 7);
	ANTS -> connectCITIES (6, 7);*/
        ANTS -> connectCITIES (0, 1);
	ANTS -> connectCITIES (0, 4);
	//ANTS -> connectCITIES (1, 0);
	ANTS -> connectCITIES (1, 2);
	ANTS -> connectCITIES (1, 5);
	//ANTS -> connectCITIES (2, 1);
	ANTS -> connectCITIES (2, 3);
	ANTS -> connectCITIES (2, 6);
	//ANTS -> connectCITIES (3, 2);
	ANTS -> connectCITIES (3, 7);
	ANTS -> connectCITIES (4, 0);
	ANTS -> connectCITIES (4, 8);
	ANTS -> connectCITIES (4, 5);
	//ANTS -> connectCITIES (5, 4);
	//ANTS -> connectCITIES(5, 1);
	ANTS -> connectCITIES(5, 6);
	ANTS -> connectCITIES(5, 9); 
        //ANTS -> connectCITIES(6, 5);
	//ANTS -> connectCITIES(6, 2);
	ANTS -> connectCITIES(6, 7);
        ANTS -> connectCITIES(6, 10);
	//ANTS -> connectCITIES(7, 6);
	//ANTS -> connectCITIES(7, 3);
        ANTS -> connectCITIES(7, 11);
	ANTS -> connectCITIES(8, 9); 
        ANTS -> connectCITIES(8, 4);
	ANTS -> connectCITIES(8, 12);
	//ANTS -> connectCITIES(9, 5);
        //ANTS -> connectCITIES(9, 8);
	ANTS -> connectCITIES(9, 10);
	ANTS -> connectCITIES(9, 13);
        //ANTS -> connectCITIES(10, 6);
	//ANTS -> connectCITIES(10, 9); 
        ANTS -> connectCITIES(10, 11);
	ANTS -> connectCITIES(10, 14);
	//ANTS -> connectCITIES(11, 7);
        //ANTS -> connectCITIES(11, 10);
	ANTS -> connectCITIES(11, 15);
	//ANTS -> connectCITIES(12, 8);
        ANTS -> connectCITIES(12, 13);
	//ANTS -> connectCITIES(13, 9);
	//ANTS -> connectCITIES(13, 12);
        ANTS -> connectCITIES(13, 14);
	//ANTS -> connectCITIES(14, 13);
	//ANTS -> connectCITIES(14, 10);
        ANTS -> connectCITIES(14, 15);
        //ANTS -> connectCITIES(15, 14);
	//ANTS -> connectCITIES(15, 11);
	//ANTS -> connectCITIES(14, 10);


	ANTS -> setCITYPOSITION (0,  1,  1);
	ANTS -> setCITYPOSITION (1, 10, 10);
	ANTS -> setCITYPOSITION (2, 20, 10);
	ANTS -> setCITYPOSITION (3, 10, 30);
	ANTS -> setCITYPOSITION (4, 15,  5);
	ANTS -> setCITYPOSITION (5, 10,  1);
	ANTS -> setCITYPOSITION (6, 20, 20);
	ANTS -> setCITYPOSITION (7, 20, 30);
        ANTS -> setCITYPOSITION (8, 26, 10);
	ANTS -> setCITYPOSITION (9, 10, 12);
	ANTS -> setCITYPOSITION (10, 20, 15);
	ANTS -> setCITYPOSITION (11, 16, 30);
	ANTS -> setCITYPOSITION (12, 15, 25);
	ANTS -> setCITYPOSITION (13, 10, 11);
	ANTS -> setCITYPOSITION (14, 20, 22);
	ANTS -> setCITYPOSITION (15, 22, 32);
	// ANTS -> setCITYPOSITION(8, 26, 20);
        sscanf(argv[1], "%d", &gh);
       // gh--;
        sscanf(argv[2], "%d", &gh1);
        gh1--;
	ANTS -> printGRAPH ();

	ANTS -> printPHEROMONES ();

	ANTS -> optimize (ITERATIONS);

	ANTS -> printRESULTS (gh1);

	return 0;
}
